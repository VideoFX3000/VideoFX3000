#include "VideoEngine.h"
using namespace cv;
using namespace std;

VideoEngine::VideoEngine(void)
	: frameWidth (0)
	, frameHeight(0)
	, input(0)
	, effectType(0)
	, writerCheck(false)
	, delayTime(0)
	, bufferSize(2)
{ 
}

VideoEngine::~VideoEngine(void)
{
}

bool VideoEngine::openVideo(const string& path, const char& effectType){
	videoCapture.open(path);
	this->effectType = effectType;
	if (videoCapture.isOpened()){
		frameNumber = 0;
		frameWidth = videoCapture.get(CV_CAP_PROP_FRAME_WIDTH);
		frameHeight = videoCapture.get(CV_CAP_PROP_FRAME_HEIGHT);
		frameRate = videoCapture.get(CV_CAP_PROP_FPS);

		namedWindow("Video");
		if (effectType == '1'){
			delay.initialize(frameWidth, frameHeight);
			return true;
		}
		else if (effectType == '2'){
			loop.initialize(frameWidth, frameHeight);
			return true;
		}
		else if (effectType == '3'){
			magic.initialize(frameWidth, frameHeight);
			return true;
		}

		/*
		switch(effectType){
		case '1': delay.initialize(frameWidth, frameHeight);
		break;
		case '2': loop.initialize(frameWidth, frameHeight);
		break;
		}		
		*/		return true;
	}
	else {
		return false;
	}
}

void VideoEngine::runVideo(){
	createTrackbar("Thresh", "Video", 0, 255);
	setTrackbarPos("Thresh", "Video", 20);

	while(true && input != 'c'){
		Mat videoFrame (frameHeight, frameWidth, CV_8UC3);
		if (!videoCapture.read(videoFrame))
			break;
		frameNumber++;
		showVideoFrame(videoFrame);

		if(kbhit())
			input = getch();
		if(input == 'r' || writerCheck == true)
			writeVideo(videoFrame);
		if(input == 's'){
			stopVideo(videoFrame);
		}

		if (effectType == '1'){
			videoFrame = delay.processFrame(videoFrame);
		}
		else if (effectType == '2'){
			loop.loopInputCheck(input, delayTime);
			if (input == 'l'){
				delayTime = 0;
				writerCheck = false;
			}
		}
		else if (effectType == '3'){
			videoFrame = magic.processFrame(videoFrame);
		}
		/*
		switch(effectType){
		case '1': videoFrame = delay.processFrame(videoFrame);//HIER jeweiligen effect (loop/delay) einsetzen
		//HIER sp�ter evtl. Aufruf von process(videoFrame)
		break;
		case '2': //loopeffekte
		break;
		}
		*/		waitKey(30);
	}
	input = '0';
}
//schreibt aktuelle Videodatei
void VideoEngine::writeVideo(const Mat& videoFrame){
	if(!writerCheck){
		cout << "---writing" << endl;	
		//videoWriter.open("Video.avi", CV_FOURCC('D', 'I', 'V', 'X'), frameRate, Size(frameWidth, frameHeight), true);
		writerCheck = true;
	}
	//videoWriter.write(videoFrame);
	loop.bufferLooper.resizeBuffer(bufferSize);
	loop.bufferLooper.writeBuffer(videoFrame);
	bufferSize++;
	delayTime++;
}
//stoppt Videoschreiben
void VideoEngine::stopVideo(const Mat& videoFrame){	
	if (writerCheck){
		cout << "---stop" << endl;
		writerCheck = false;
	}
	//videoWriter.release();
}

void VideoEngine::showVideoFrame(const Mat&videoFrame){
	imshow("Video", videoFrame);
}

void VideoEngine::showProcessedFrame(const Mat&processedFrame){
	imshow("Result", processedFrame);

}