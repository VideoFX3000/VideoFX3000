#ifndef MAGICCAPEFFECT_H
#define MAGICCAPEFFECT_H

#include "Effect.h"

class MagicCapEffect : public Effect
{
public:
	MagicCapEffect(void);
	virtual ~MagicCapEffect(void);
	virtual void setTool(ToolInterface *tool);
	void initialize(int frameWidth, int frameHeight);
	cv::Mat processFrame(cv::Mat input);
private:
	int frameWidth;
	int frameHeight;
	// Z�hlvariable, die hochgez�hlt wird
	int frameNumber;
	// Pointer vom Typ ToolInterface
	ToolInterface *tool;
	cv::Mat firstFrame;
	int capIntensityR;
	int capIntensityG;
	int capIntensityB;
	float capIntensityAlpha;
};

#endif

