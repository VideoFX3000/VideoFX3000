#include "LooperEffect.h"
#include <iostream>
#include "Backgroundsubstraction.h"
using namespace std;
using namespace cv;

LooperEffect::LooperEffect(void)
	: frameWidth(0)
	, frameHeight(0)
	, tool(0)
{
	setTool(new Backgroundsubstraction());
}


LooperEffect::~LooperEffect(void)
{
}

void LooperEffect::initialize(int frameWidth, int frameHeight){
	this->frameWidth = frameWidth;
	this->frameHeight = frameHeight;
}

void LooperEffect::loopInputCheck(int input, int delayTime){
	if(input == 'l')
		loopVideo(delayTime);
	//waitKey(30);
}

/*Mat LooperEffect::processFrame(cv::Mat& processedFrame){
processedFrame = tool->process(processedFrame);
return processedFrame;
}*/

void LooperEffect::loopVideo(int delayTime){

	cout << "---looping" << endl;
	char abfrage = '0';
	//VideoCapture loopedVideo;
	//loopedVideo.open("Video.avi");
	//cout << loopedVideo.isOpened() << endl;

	while(abfrage != 'q'){
		if(kbhit()){
			abfrage = getch();
			break;
		}
		for (int i = 0; i < delayTime; i++){
			Mat videoFrame (frameHeight, frameWidth, CV_8UC3);
			//if (loopedVideo.read(videoFrame) == false)
			//break;
			bufferLooper.readWithDelay(delayTime-i).copyTo(videoFrame);
			imshow("Video", videoFrame);
			waitKey(30);
		}
	}
}


void LooperEffect::setTool(ToolInterface *tool){
	//this->tool = tool;
}